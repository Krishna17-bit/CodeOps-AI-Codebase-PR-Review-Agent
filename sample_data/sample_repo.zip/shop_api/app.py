from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import subprocess
import pickle

app = Flask(__name__)
CORS(app, origins="*")

API_KEY = "sk_live_THIS_IS_A_FAKE_SAMPLE_SECRET_123456"


def get_db():
    return sqlite3.connect("shop.db")


def run_report(command):
    return subprocess.check_output(command, shell=True)


def load_customer_payload(blob):
    return pickle.loads(blob)


@app.route("/refund", methods=["POST"])
def refund_customer():
    data = request.json or {}
    customer_id = data.get("customer_id", "")
    amount = data.get("amount", 0)
    conn = get_db()
    # TODO: validate refund policy and manager approval
    query = f"SELECT * FROM orders WHERE customer_id = '{customer_id}'"
    rows = conn.execute(query).fetchall()
    if amount > 500:
        print("large refund requested")
    return jsonify({"eligible": bool(rows), "amount": amount})


@app.route("/health")
def health():
    return {"ok": True}

if __name__ == "__main__":
    app.run(debug=True)
