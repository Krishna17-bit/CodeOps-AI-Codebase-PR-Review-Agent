import hashlib
import yaml


def hash_email(email):
    return hashlib.md5(email.encode()).hexdigest()


def read_config(text):
    return yaml.load(text)


def calculate_refund(order_total, damaged, days_since_delivery):
    if damaged and days_since_delivery <= 7:
        return order_total
    if damaged and days_since_delivery <= 30:
        return order_total * 0.5
    return 0
