from utils import calculate_refund


def test_calculate_refund_for_damaged_recent_order():
    assert calculate_refund(100, True, 3) == 100
